#include <transform_hw/Transformer.h>

using namespace std;

Transformer::Transformer(ros::NodeHandle &_nh) {
    _sub = _nh.subscribe("/azure_kinect/tag_pose", 1000, &Transformer::poseCallback, this);
}

Transformer::~Transformer() {}

//This method DEFINITELY takes a parameter. Can you figure out what it is?
void Transformer::poseCallback(const geometry_msgs::PoseStamped &_msg) {
    /*
        The incoming message will be a geometry_msgs::PoseStamped.
        It will contain all of the following information EXCEPT CHILD FRAME.

        PROBLEM 1, as in the PDF:
        Get the correct information out of the incoming message.
        Print it using ROS_INFO_STREAM.

        Hint: You can look up where in the message the data are on this page!
        http://docs.ros.org/en/noetic/api/geometry_msgs/html/msg/PoseStamped.html

        The child frame will be april_tag
    */

        ROS_INFO_STREAM("PARENT FRAME:   " << _msg.header.frame_id << endl <<
        "CHILD FRAME:    " << "april_tag" << endl <<
        "Translation X:  " << _msg.pose.position.x << endl <<
        "Translation Y:  " << _msg.pose.position.y << endl <<
        "Translation Z:  " << _msg.pose.position.z << endl <<
        "Rotation X:     " << _msg.pose.orientation.x << endl <<
        "Rotation Y:     " << _msg.pose.orientation.y << endl <<
        "Rotation Z:     " << _msg.pose.orientation.z << endl <<
        "Rotation W:     " << _msg.pose.orientation.w << endl);
    
    /*
        PROBLEM 2, as in the PDF:

        Take the contents of the PoseStamped message received in this callback.
        Use them to fill in a geometry_msgs::TransformStamped, and send it
            the information as a transform using TF2.
        The tutorial about using TF2 to send transforms is in the header file
            for this class.
        Call this transform's frame "april_tag".
        Its parent frame should be "azure_kinect/camera_body".
    
    */

    // create broadcaster object used to send transfomrations
    static tf2_ros:: TransformBroadcaster br;

    // create the transform object and assign the appropriate information
    geometry_msgs::TransformStamped ts1;
    ts1.header = _msg.header;

    ts1.header.stamp = ros::Time::now();
    ts1.child_frame_id = "april_tag";
    ts1.header.frame_id = "azure_kinect/camera_body";

    // copy translation
    ts1.transform.translation.x = _msg.pose.position.x;
    ts1.transform.translation.y = _msg.pose.position.y;
    ts1.transform.translation.z = _msg.pose.position.z;
    
    // copy rotations
    ts1.transform.rotation.x = _msg.pose.orientation.x;
    ts1.transform.rotation.y = _msg.pose.orientation.y;
    ts1.transform.rotation.z = _msg.pose.orientation.z;
    ts1.transform.rotation.w = _msg.pose.orientation.w;

    // send the transformation
    br.sendTransform(ts1);

    /*
        PROBLEM 3, as in the PDF:

        Publish a transform that is 1 meter (1.0) in front of "april_tag"
            and in the same orientation (all axes facing the same direction).
            This means 1 meter in front of the face of the marker, as in
            sticking out in front of the marker along its z axis.    

        1) Remember that transformations form chains from the "proximal" frame
            to the "distal" frame. In this case, the "proximal" frame is the
            camera "azure_kinect/camera_body". The "distal" frame is the point
            one meter in front of the marker .
        2) Use Eigen to build your chain of transformations:
            A) Chains of transformations are covered in
                Lec_Spatial_Transformations.pdf
            B) Eigen is covered in Lec_Eigen.pdf
            C) The mathematics are covered in Lec_Transformation_Mat.pdf
        3) The basic version of how to do this is:
            A) Use Eigen::Quaterniond to get the rotation matrix from the
                quaternion in geometry_msgs::PoseStamped that is received by
                this callback.
            B) Build a rigid transformation representing the transform between
                the camera and the marker. The rigid transformation is as in
                Lec_Transformation_Math. It is a 4x4 matrix (Eigen::MatrixXd).
                The upper-left 3x3 submatrix is the rotation (which can be)
                obtained from the Quaterniond that you just built using
                Eigen::Quaterniond::toRotationMatrix() The right column of the
                matrix is the translation, which can be obtained directly from
                the geometry_msgs::PoseStamped that is received by this
                callback.
                The matrix that you have just built is the rigid transformation
                between the camera and the marker.
            C) Build a rigid transformation representing the concept of "one
                meter in front along the z-axis." This transformation has an
                identity rotation component. It has 1.0 in the z translational
                component. Hint: Start by using Eigen::MatrixXd::Identity(4,4).
            D) Multiply the rigid transformation from the camera to the marker,
                and the one from the marker to the offset.
            E) Populate an Eigen::Quaterniond to figure out the quaternion 
                representing the orientation of the offset point.
                You can do this by initializing a new Eigen::Quaterniond with
                the submatrix from the 4x4 rigid transformation (the result)
                of the multiplication in Step D.
                This is a little tricky, so I'll show you what my code looks
                like here:
                Eigen::Quaterniond offsetQ(offsetOutMat.block<3,3>(0,0));
                Hint: Since the offset is facing the same direction as the
                marker, there *is* another way.
            F) Make a geometry_msgs::TransformStamped, pack it with the 
                transform to the offset. Send it.
	        G) HINT: You will have problems with your quaternion after you
		        send it if it is not normalized. So, normalize it before
                putting it into your TransformStamped. To do this, use
                Eigen::Quaterniond::normalize(). In my code, it looks like
                offsetQ.normalize();
    
    */

    Eigen::Quaterniond quat(_msg.pose.orientation.w, _msg.pose.orientation.x, _msg.pose.orientation.y, _msg.pose.orientation.z);
    quat.normalize();

    Eigen::MatrixXd cam_Mark(4, 4);
    cam_Mark(0, 3) = _msg.pose.position.x;
    cam_Mark(1, 3) = _msg.pose.position.y;
    cam_Mark(2, 3) = _msg.pose.position.z;

    Eigen::MatrixXd offset = Eigen::MatrixXd::Identity(4,4);
    offset(2, 3) = 1;

    cam_Mark.block(0, 0, 3, 3) = quat.toRotationMatrix();

    Eigen::MatrixXd rigidTrans = cam_Mark * offset;


    geometry_msgs::TransformStamped ts2;

    ts2.header.stamp = ros::Time::now();
    ts2.child_frame_id = "offset";
    ts2.header.frame_id = _msg.header.frame_id;

    ts2.transform.translation.x = rigidTrans(0, 3);
    ts2.transform.translation.y = rigidTrans(1, 3);
    ts2.transform.translation.z = rigidTrans(2, 3);

    ts2.transform.rotation.x = ts1.transform.rotation.x;
    ts2.transform.rotation.y = ts1.transform.rotation.y;
    ts2.transform.rotation.z = ts1.transform.rotation.z;
    ts2.transform.rotation.w = ts1.transform.rotation.w;
    
    br.sendTransform(ts2);
 
    /*
        PROBLEM 4, as in the PDF:

        Publish a transform that is 1 meter (1.0) in front of "april_tag"
            but is rotated 180 degrees about its Y axis.
    
        How to do this:
        1) Do all of the steps from PROBLEM 3.
        2) Add a final rotation at the end about the Y axis.
        3) HINT: Use Eigen::AngleAxisd to achieve this, with M_PI and
            Eigen::Vector3d::UnitY()
    
    */

    geometry_msgs::TransformStamped ts3;

    Eigen::Quaterniond offsetQ(rigidTrans.block<3, 3>(0,0));

    Eigen::Quaterniond offset_rotate(Eigen::AngleAxisd(M_PI, Eigen::Vector3d::UnitY()));
    Eigen::MatrixXd rotateTrans = Eigen::MatrixXd::Identity(4,4);
    rotateTrans.block(0, 0, 3 ,3) = offset_rotate.toRotationMatrix();

    cam_Mark.block(0, 0, 3, 3) = quat.toRotationMatrix();
    Eigen::MatrixXd rigidTransA = cam_Mark * offset;

    rigidTransA = rigidTransA * rotateTrans;
    Eigen::Quaterniond offsetQ1(rigidTransA.block<3, 3>(0, 0));

    ts3.child_frame_id = "offset_flip";
    ts3.header.frame_id = _msg.header.frame_id;
    ts3.header.stamp = ros::Time::now();

    ts3.transform.translation.x = rigidTrans(0, 3);
    ts3.transform.translation.y = rigidTrans(1, 3);
    ts3.transform.translation.z = rigidTrans(2, 3);

    ts3.transform.rotation.x = offsetQ1.x();
    ts3.transform.rotation.y = offsetQ1.y();
    ts3.transform.rotation.z = offsetQ1.z();
    ts3.transform.rotation.w = offsetQ1.w();
    br.sendTransform(ts3);
}
